# console-based-tweetapp
An console based java application which can post tweets

# how it works
1. download the project by cloning it or zip.
2. open the project in eclipse ide (preferred).
3. If needed, update the project by right click on the project -> Maven -> Update Project.
4. Install Xaamp from https://www.apachefriends.org/download.html and keep the Apache, MySql running.
5. Run the App.java file in com.tweetapp.console_based_tweet_app package
6. In the console you can view the options to start the app.

# Enjoy the Tweet app :)
